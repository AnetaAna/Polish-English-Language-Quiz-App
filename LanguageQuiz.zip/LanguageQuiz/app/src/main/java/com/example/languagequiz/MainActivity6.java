package com.example.languagequiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        Button gramback = (Button) findViewById(R.id.gramback);

        gramback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity6.this, MainActivity0.class));
            }
        });

            String word = "MAM";
            EditText gramedit = (EditText) findViewById(R.id.gramedit);

            Button checkone = (Button) findViewById(R.id.checkone);

            checkone.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {

                if(word.equalsIgnoreCase(gramedit.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

            } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: MAM", Toast.LENGTH_SHORT).show();
                }
        }
    });

        String wordtwo = "MASZ";
        EditText gramedittwo = (EditText) findViewById(R.id.gramedittwo);

        Button checktwo = (Button) findViewById(R.id.checktwo);

        checktwo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordtwo.equalsIgnoreCase(gramedittwo.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: MASZ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordthree = "SIĘ";
        EditText grameditthree = (EditText) findViewById(R.id.grameditthree);

        Button checkthree = (Button) findViewById(R.id.checkthree);

        checkthree.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordthree.equalsIgnoreCase(grameditthree.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: SIĘ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordfour = "SKĄD";
        EditText grameditfour = (EditText) findViewById(R.id.grameditfour);

        Button checkfour = (Button) findViewById(R.id.checkfour);

        checkfour.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordfour.equalsIgnoreCase(grameditfour.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: SKĄD", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordfive = "MIESZKASZ";
        EditText grameditfive = (EditText) findViewById(R.id.grameditfive);

        Button checkfive = (Button) findViewById(R.id.checkfive);

        checkfive.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordfive.equalsIgnoreCase(grameditfive.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: MIESZKASZ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordsix = "ROBI";
        EditText grameditsix = (EditText) findViewById(R.id.grameditsix);

        Button checksix = (Button) findViewById(R.id.checksix);

        checksix.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordsix.equalsIgnoreCase(grameditsix.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: ROBI", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordseven = "SĄ";
        EditText grameditseven = (EditText) findViewById(R.id.grameditseven);

        Button checkseven = (Button) findViewById(R.id.checkseven);

        checkseven.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordseven.equalsIgnoreCase(grameditseven.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: SĄ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordeight = "MAM";
        EditText gramediteight = (EditText) findViewById(R.id.gramediteight);

        Button checkeight = (Button) findViewById(R.id.checkeight);

        checkeight.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordeight.equalsIgnoreCase(gramediteight.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: MAM", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordnine = "ROBIĆ";
        EditText grameditnine = (EditText) findViewById(R.id.grameditnine);

        Button checknine = (Button) findViewById(R.id.checknine);

        checknine.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordnine.equalsIgnoreCase(grameditnine.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: ROBIĆ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        String wordten = "JESTEŚCIE";
        EditText grameditten = (EditText) findViewById(R.id.grameditten);

        Button checkten = (Button) findViewById(R.id.checkten);

        checkten.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if(wordten.equalsIgnoreCase(grameditten.getText().toString())) {
                    Toast.makeText(MainActivity6.this,"That's correct!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity6.this,"Sorry! The correct answer is: JESTEŚCIE", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }}